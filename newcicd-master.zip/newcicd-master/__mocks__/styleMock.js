// __mocks__/styleMock.js

module.exports = {};
